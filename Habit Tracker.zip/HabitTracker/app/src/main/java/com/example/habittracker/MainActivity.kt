package com.example.habittracker

import android.os.Bundle
import android.widget.DatePicker
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import java.util.*
import android.app.DatePickerDialog

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            HabitTrackerApp()
        }
    }
}

@Composable
fun HabitTrackerApp() {
    var activeHabits by remember { mutableStateOf(mutableListOf(Habit("Exercise"), Habit("Read"), Habit("Meditate"))) }
    var completedHabits by remember { mutableStateOf(mutableListOf<Habit>()) }
    var newHabit by remember { mutableStateOf("") }
    var selectedTab by remember { mutableStateOf(0) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(text = "Habit Tracker", fontSize = 24.sp, color = Color(0xFF3B4F62))
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = newHabit,
            onValueChange = { newHabit = it },
            label = { Text("New Habit") },
            singleLine = true
        )
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = {
            if (newHabit.isNotBlank()) {
                activeHabits.add(Habit(newHabit))
                newHabit = ""
            }
        }) {
            Text("Add Habit")
        }
        Spacer(modifier = Modifier.height(16.dp))

        TabRow(selectedTabIndex = selectedTab) {
            Tab(text = { Text("Active Habits") }, selected = selectedTab == 0, onClick = { selectedTab = 0 })
            Tab(text = { Text("Completed Habits") }, selected = selectedTab == 1, onClick = { selectedTab = 1 })
            Tab(text = { Text("Daily Progress") }, selected = selectedTab == 2, onClick = { selectedTab = 2 })
        }

        Spacer(modifier = Modifier.height(16.dp))

        when (selectedTab) {
            0 -> HabitList(activeHabits, isCompleted = false, onHabitToggle = { habit ->
                activeHabits = activeHabits.filterNot { it == habit }.toMutableList()
                completedHabits.add(habit)
            }, onDeleteHabit = { habit ->
                activeHabits = activeHabits.filterNot { it == habit }.toMutableList()
            })
            1 -> HabitList(completedHabits, isCompleted = true, onHabitToggle = { habit ->
                completedHabits = completedHabits.filterNot { it == habit }.toMutableList()
                activeHabits.add(habit)
            }, onDeleteHabit = { habit ->
                completedHabits = completedHabits.filterNot { it == habit }.toMutableList()
            })
            2 -> DailyProgressTab(activeHabits, completedHabits)
        }
    }
}

@Composable
fun HabitList(habits: List<Habit>, isCompleted: Boolean, onHabitToggle: (Habit) -> Unit, onDeleteHabit: (Habit) -> Unit) {
    habits.forEach { habit ->
        HabitItem(habit, isCompleted, onToggle = { onHabitToggle(habit) }, onDelete = { onDeleteHabit(habit) })
    }
}

@Composable
fun HabitItem(habit: Habit, isCompleted: Boolean, onToggle: () -> Unit, onDelete: () -> Unit) {
    var showDatePicker by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val calendar = habit.selectedDate

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .background(Color(0xFF9FB4D3), shape = RoundedCornerShape(8.dp))
            .clickable { onToggle() }
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = habit.name, fontSize = 18.sp, color = Color.White)

        Row {
            // Checkbox for completed/active task
            Checkbox(
                checked = isCompleted, // Check if it's completed
                onCheckedChange = null, // Disable interaction in completed tasks
                colors = CheckboxDefaults.colors(checkedColor = Color(0xFF4A9E88), uncheckedColor = Color.White)
            )

            // Calendar Icon Button
            IconButton(onClick = {
                showDatePicker = true
            }) {
                Icon(imageVector = Icons.Filled.DateRange, contentDescription = "Set Reminder Date", tint = Color.White)
            }

            // Delete Button
            IconButton(onClick = onDelete) {
                Icon(imageVector = Icons.Filled.Delete, contentDescription = "Delete Habit", tint = Color.White)
            }
        }

        // Show selected date
        Text("Reminder Date: ${calendar.get(Calendar.DAY_OF_MONTH)}/${calendar.get(Calendar.MONTH) + 1}/${calendar.get(Calendar.YEAR)}")

        if (showDatePicker) {
            DatePickerDialog(context, { _, year, month, dayOfMonth ->
                habit.selectedDate.set(year, month, dayOfMonth) // Update the habit's selected date
                showDatePicker = false // Close the date picker
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
        }
    }
}

@Composable
fun DailyProgressTab(activeHabits: List<Habit>, completedHabits: List<Habit>) {
    val currentDate = Calendar.getInstance()
    val todayCompleted = completedHabits.filter { it.selectedDate.isSameDayAs(currentDate) }.size
    val todayTotal = activeHabits.size + todayCompleted

    // Calculate the completion percentage
    val completionPercentage = if (todayTotal > 0) (todayCompleted.toFloat() / todayTotal.toFloat()) * 100 else 0f

    // Calculate the color based on the completion percentage (more completion = greener)
    val boxColor = Color(0xFF4A9E88).copy(alpha = completionPercentage / 100)

    Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
        Text(text = "Daily Progress", fontSize = 24.sp, color = Color(0xFF3B4F62))
        Spacer(modifier = Modifier.height(16.dp))

        // Display the colored box with the date and completion percentage
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(100.dp)
                .background(boxColor, shape = RoundedCornerShape(8.dp))
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Today: ${currentDate.get(Calendar.DAY_OF_MONTH)}",
                fontSize = 20.sp,
                color = Color.White
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Show today's progress
        Text("Tasks Completed Today: $todayCompleted")
        Text("Total Tasks Today: $todayTotal")
        Text("Remaining Tasks: ${todayTotal - todayCompleted}")
    }
}

fun Calendar.isSameDayAs(other: Calendar): Boolean {
    return this.get(Calendar.YEAR) == other.get(Calendar.YEAR) &&
            this.get(Calendar.DAY_OF_YEAR) == other.get(Calendar.DAY_OF_YEAR)
}

data class Habit(
    val name: String,
    var selectedDate: Calendar = Calendar.getInstance()
)

@Preview(showBackground = true)
@Composable
fun PreviewHabitTrackerApp() {
    HabitTrackerApp()
}
